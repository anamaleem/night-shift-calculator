<?php
/**
 * Plugin Name: Night Shift Pay Calculator
 * Description: A professional night shift pay calculator with 20% premium calculation
 * Version: 1.0.0
 * Author: Your Name
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class NightShiftPayCalculator {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_shortcode('night_shift_calculator', array($this, 'render_calculator'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
    }
    
    public function init() {
        // Plugin initialization
    }
    
    public function enqueue_scripts() {
        if (is_singular() && has_shortcode(get_post()->post_content, 'night_shift_calculator')) {
            wp_enqueue_script('night-shift-calculator', plugin_dir_url(__FILE__) . 'night-shift-calculator.js', array(), '1.0.0', true);
            wp_enqueue_style('night-shift-calculator', plugin_dir_url(__FILE__) . 'night-shift-calculator.css', array(), '1.0.0');
        }
    }
    
    public function render_calculator($atts) {
        // Shortcode attributes
        $atts = shortcode_atts(array(
            'currency' => 'USD',
            'currency_symbol' => '$',
            'title' => 'Night Shift Pay Calculator',
            'description' => 'Calculate your night shift premium with 20% additional compensation'
        ), $atts);
        
        ob_start();
        ?>
        <div class="night-shift-calculator-wp">
            <div class="calculator-container">
                <div class="calculator-header">
                    <h2><?php echo esc_html($atts['title']); ?></h2>
                    <p><?php echo esc_html($atts['description']); ?></p>
                </div>

                <div class="calculator-content">
                    <div class="disclaimer">
                        <h4>⚠️ Important Disclaimer</h4>
                        <p>This calculation is an estimate based on standard labor practices. Consult with a professional for specific cases or local regulations. Results may vary based on your employment contract and local laws.</p>
                    </div>

                    <div class="input-section">
                        <div class="input-row">
                            <div class="input-group">
                                <label for="monthlySalary">Monthly Base Salary (<?php echo esc_html($atts['currency_symbol']); ?>)</label>
                                <input type="number" id="monthlySalary" placeholder="3000" min="0" step="0.01">
                                <div class="error-message" id="salaryError"></div>
                            </div>

                            <div class="input-group">
                                <label for="totalHours">Total Monthly Hours</label>
                                <input type="number" id="totalHours" placeholder="160" min="1" max="300">
                                <div class="error-message" id="hoursError"></div>
                            </div>
                        </div>

                        <div class="input-row">
                            <div class="input-group">
                                <label for="nightHours">Night Shift Hours per Month</label>
                                <input type="number" id="nightHours" placeholder="40" min="0">
                                <div class="error-message" id="nightError"></div>
                            </div>

                            <div class="input-group">
                                <label for="overtimeHours">Overtime Hours at Night (Optional)</label>
                                <input type="number" id="overtimeHours" placeholder="0" min="0" value="0">
                                <div class="error-message" id="overtimeError"></div>
                            </div>
                        </div>

                        <button class="calculate-btn" onclick="calculateNightShiftWP('<?php echo esc_js($atts['currency']); ?>', '<?php echo esc_js($atts['currency_symbol']); ?>')">
                            Calculate Night Shift Premium
                        </button>
                    </div>

                    <div class="results" id="results">
                        <div class="results-grid">
                            <div class="result-card">
                                <h4>Monthly Night Premium</h4>
                                <div class="value" id="monthlyPremium"><?php echo esc_html($atts['currency_symbol']); ?>0.00</div>
                                <small>Additional compensation</small>
                            </div>
                            <div class="result-card highlight">
                                <h4>Total with Premium</h4>
                                <div class="value" id="totalWithPremium"><?php echo esc_html($atts['currency_symbol']); ?>0.00</div>
                                <small>Base salary + night premium</small>
                            </div>
                        </div>

                        <div class="breakdown">
                            <h4>Calculation Breakdown</h4>
                            <div class="breakdown-item">
                                <span class="breakdown-label">Regular Hourly Rate:</span>
                                <span class="breakdown-value" id="regularRate"><?php echo esc_html($atts['currency_symbol']); ?>0.00</span>
                            </div>
                            <div class="breakdown-item">
                                <span class="breakdown-label">Night Premium (20%):</span>
                                <span class="breakdown-value" id="nightPremium"><?php echo esc_html($atts['currency_symbol']); ?>0.00</span>
                            </div>
                            <div class="breakdown-item">
                                <span class="breakdown-label">Night Hourly Rate:</span>
                                <span class="breakdown-value" id="nightHourlyRate"><?php echo esc_html($atts['currency_symbol']); ?>0.00</span>
                            </div>
                            <div class="breakdown-item">
                                <span class="breakdown-label">Reduced Night Hours:</span>
                                <span class="breakdown-value" id="reducedHours">0</span>
                            </div>
                            <div class="breakdown-item" id="overtimeSection" style="display: none;">
                                <span class="breakdown-label">Overtime Rate (Night):</span>
                                <span class="breakdown-value" id="overtimeRate"><?php echo esc_html($atts['currency_symbol']); ?>0.00</span>
                            </div>
                        </div>

                        <button class="print-btn" onclick="window.print()">
                            🖨️ Print Results
                        </button>
                    </div>

                    <div class="info-section">
                        <h3>🔍 How Night Shift Premium Works</h3>
                        <ul>
                            <li><strong>20% Premium:</strong> Additional compensation for night work</li>
                            <li><strong>Reduced Hours:</strong> 52.5 minutes = 1 hour (recognizes night work difficulty)</li>
                            <li><strong>Overtime Combination:</strong> Night overtime gets both premiums</li>
                            <li><strong>Monthly Calculation:</strong> Based on total hours worked</li>
                            <li><strong>Professional Use:</strong> Suitable for payroll and HR calculations</li>
                            <li><strong>Compliance Ready:</strong> Follows standard labor practices</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}

// Initialize the plugin
new NightShiftPayCalculator();
?>