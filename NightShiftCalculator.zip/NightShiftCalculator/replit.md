# Night Shift Pay Calculator

## Overview

This is a web-based night shift pay calculator application built with Flask and Bootstrap. The application calculates night shift premium pay with a 20% additional compensation rate and includes special handling for reduced night hours (52.5 minutes = 1 hour). The application features a professional dark theme interface with real-time calculations and form validation.

## System Architecture

### Frontend Architecture
- **Template Engine**: Jinja2 templates with Flask
- **CSS Framework**: Bootstrap 5 with custom dark theme
- **JavaScript**: Vanilla JavaScript with ES6 class-based architecture
- **UI Components**: Responsive design with FontAwesome icons
- **Theme**: Dark theme with gradient backgrounds and modern styling

### Backend Architecture
- **Framework**: Flask (Python web framework)
- **Structure**: Simple monolithic architecture
- **Session Management**: Flask sessions with configurable secret key
- **Environment Configuration**: Environment variables for sensitive data

## Key Components

### Core Files
1. **app.py**: Main Flask application with route definitions
2. **main.py**: Application entry point for deployment
3. **templates/index.html**: Single-page application template
4. **static/css/style.css**: Custom styling with CSS variables
5. **static/js/calculator.js**: Client-side calculation logic

### Calculator Features
- Monthly salary input with currency formatting
- Night shift hours tracking
- 20% night shift premium calculation
- Reduced night hours calculation (52.5 minutes = 1 hour)
- Overtime premium calculation (50% rate)
- Real-time form validation
- Professional disclaimer for legal compliance

## Data Flow

1. **User Input**: Users enter monthly salary and work hours through web form
2. **Client-side Validation**: JavaScript validates inputs in real-time
3. **Calculation Processing**: Browser-based calculations using predefined rates
4. **Result Display**: Dynamic updates to the UI with calculated premiums
5. **No Server Processing**: All calculations happen client-side for performance

## External Dependencies

### CDN Resources
- Bootstrap 5 (Replit custom dark theme)
- FontAwesome 6.0.0 for icons
- No external API dependencies

### Python Dependencies
- Flask framework
- Standard library modules (os)

## Deployment Strategy

### Development Environment
- Flask development server on port 5000
- Debug mode enabled for development
- Host binding to 0.0.0.0 for container compatibility

### Production Considerations
- Environment-based secret key configuration
- Static file serving through Flask (suitable for small-scale deployment)
- Single-threaded Flask server (suitable for personal/small business use)

### Scaling Options
- Can be deployed on cloud platforms (Heroku, Railway, etc.)
- Static assets can be served via CDN
- Database integration possible for storing calculation history

## Changelog

Changelog:
- July 04, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.