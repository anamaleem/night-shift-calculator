/**
 * Night Shift Pay Calculator
 * Calculates night shift premium with 20% additional compensation
 * and reduced night hours (52.5 minutes = 1 hour)
 */

class NightShiftCalculator {
    constructor() {
        this.nightPremiumRate = 0.20; // 20% premium
        this.overtimePremiumRate = 0.50; // 50% overtime premium
        this.nightHourReduction = 0.875; // 52.5 minutes = 1 hour (52.5/60 = 0.875)
        
        this.initializeEventListeners();
    }

    initializeEventListeners() {
        const form = document.getElementById('nightShiftForm');
        const inputs = form.querySelectorAll('input');
        
        // Form submission
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.calculateNightShiftPay();
        });

        // Real-time validation
        inputs.forEach(input => {
            input.addEventListener('input', () => {
                this.validateInput(input);
            });
        });
    }

    validateInput(input) {
        const value = parseFloat(input.value);
        const isValid = !isNaN(value) && value >= 0;
        
        if (input.value && !isValid) {
            input.classList.add('is-invalid');
            this.showError(input, 'Please enter a valid positive number');
        } else {
            input.classList.remove('is-invalid');
            this.clearError(input);
        }

        // Validate that night hours don't exceed total hours
        if (input.id === 'nightHours' || input.id === 'totalHours') {
            this.validateHoursLogic();
        }
    }

    validateHoursLogic() {
        const totalHours = parseFloat(document.getElementById('totalHours').value) || 0;
        const nightHours = parseFloat(document.getElementById('nightHours').value) || 0;
        const overtimeHours = parseFloat(document.getElementById('overtimeHours').value) || 0;
        
        const nightInput = document.getElementById('nightHours');
        const overtimeInput = document.getElementById('overtimeHours');
        
        if (nightHours > totalHours) {
            nightInput.classList.add('is-invalid');
            this.showError(nightInput, 'Night hours cannot exceed total hours');
        } else {
            nightInput.classList.remove('is-invalid');
            this.clearError(nightInput);
        }

        if (overtimeHours > nightHours) {
            overtimeInput.classList.add('is-invalid');
            this.showError(overtimeInput, 'Overtime hours cannot exceed night hours');
        } else {
            overtimeInput.classList.remove('is-invalid');
            this.clearError(overtimeInput);
        }
    }

    showError(input, message) {
        let errorDiv = input.parentNode.querySelector('.invalid-feedback');
        if (!errorDiv) {
            errorDiv = document.createElement('div');
            errorDiv.className = 'invalid-feedback';
            input.parentNode.appendChild(errorDiv);
        }
        errorDiv.textContent = message;
    }

    clearError(input) {
        const errorDiv = input.parentNode.querySelector('.invalid-feedback');
        if (errorDiv) {
            errorDiv.remove();
        }
    }

    calculateNightShiftPay() {
        // Get input values
        const monthlySalary = parseFloat(document.getElementById('monthlySalary').value);
        const totalHours = parseFloat(document.getElementById('totalHours').value);
        const nightHours = parseFloat(document.getElementById('nightHours').value);
        const overtimeHours = parseFloat(document.getElementById('overtimeHours').value) || 0;

        // Validate inputs
        if (!this.validateCalculationInputs(monthlySalary, totalHours, nightHours, overtimeHours)) {
            return;
        }

        // Show loading state
        const calculateBtn = document.querySelector('button[type="submit"]');
        calculateBtn.classList.add('btn-loading');

        // Simulate calculation time for better UX
        setTimeout(() => {
            this.performCalculation(monthlySalary, totalHours, nightHours, overtimeHours);
            calculateBtn.classList.remove('btn-loading');
        }, 500);
    }

    validateCalculationInputs(monthlySalary, totalHours, nightHours, overtimeHours) {
        const errors = [];

        if (!monthlySalary || monthlySalary <= 0) {
            errors.push('Monthly salary must be greater than 0');
        }

        if (!totalHours || totalHours <= 0) {
            errors.push('Total hours must be greater than 0');
        }

        if (nightHours < 0) {
            errors.push('Night hours cannot be negative');
        }

        if (overtimeHours < 0) {
            errors.push('Overtime hours cannot be negative');
        }

        if (nightHours > totalHours) {
            errors.push('Night hours cannot exceed total hours');
        }

        if (overtimeHours > nightHours) {
            errors.push('Overtime hours cannot exceed night hours');
        }

        if (errors.length > 0) {
            this.showAlert(errors.join('<br>'), 'danger');
            return false;
        }

        return true;
    }

    performCalculation(monthlySalary, totalHours, nightHours, overtimeHours) {
        // Calculate regular hourly rate
        const regularHourlyRate = monthlySalary / totalHours;

        // Calculate night premium per hour
        const nightPremiumPerHour = regularHourlyRate * this.nightPremiumRate;

        // Calculate night hourly rate (regular + premium)
        const nightHourlyRate = regularHourlyRate + nightPremiumPerHour;

        // Calculate reduced night hours (52.5 minutes = 1 hour)
        const reducedNightHours = nightHours * this.nightHourReduction;
        const reducedOvertimeHours = overtimeHours * this.nightHourReduction;

        // Calculate regular night hours (excluding overtime)
        const regularNightHours = nightHours - overtimeHours;
        const reducedRegularNightHours = regularNightHours * this.nightHourReduction;

        // Calculate overtime rate for night shift (regular + night premium + overtime premium)
        const overtimeRate = nightHourlyRate * (1 + this.overtimePremiumRate);

        // Calculate total night shift premium
        let totalNightPremium = 0;
        
        // Regular night hours premium
        if (regularNightHours > 0) {
            totalNightPremium += nightHourlyRate * reducedRegularNightHours;
        }

        // Overtime night hours premium
        if (overtimeHours > 0) {
            totalNightPremium += overtimeRate * reducedOvertimeHours;
        }

        // Calculate what would be paid for regular hours
        const regularPayForNightHours = regularHourlyRate * reducedNightHours;
        
        // Calculate the additional premium (difference between night pay and regular pay)
        const additionalPremium = totalNightPremium - regularPayForNightHours;

        // Calculate total salary with premium
        const totalWithPremium = monthlySalary + additionalPremium;

        // Display results
        this.displayResults({
            regularHourlyRate,
            nightPremiumPerHour,
            nightHourlyRate,
            reducedNightHours,
            reducedOvertimeHours,
            overtimeRate,
            totalNightPremium,
            additionalPremium,
            totalWithPremium,
            monthlySalary,
            overtimeHours
        });
    }

    displayResults(results) {
        // Update main results
        document.getElementById('monthlyPremium').textContent = this.formatCurrency(results.additionalPremium);
        document.getElementById('totalWithPremium').textContent = this.formatCurrency(results.totalWithPremium);

        // Update detailed breakdown
        document.getElementById('regularRate').textContent = this.formatCurrency(results.regularHourlyRate);
        document.getElementById('nightPremiumRate').textContent = this.formatCurrency(results.nightPremiumPerHour);
        document.getElementById('nightHourlyRate').textContent = this.formatCurrency(results.nightHourlyRate);
        document.getElementById('reducedHours').textContent = results.reducedNightHours.toFixed(2);

        // Show/hide overtime sections
        const overtimeSection = document.getElementById('overtimeSection');
        const overtimeHoursSection = document.getElementById('overtimeHoursSection');
        
        if (results.overtimeHours > 0) {
            overtimeSection.style.display = 'block';
            overtimeHoursSection.style.display = 'block';
            document.getElementById('overtimeRate').textContent = this.formatCurrency(results.overtimeRate);
            document.getElementById('reducedOvertimeHours').textContent = results.reducedOvertimeHours.toFixed(2);
        } else {
            overtimeSection.style.display = 'none';
            overtimeHoursSection.style.display = 'none';
        }

        // Show results section with animation
        const resultsSection = document.getElementById('resultsSection');
        resultsSection.style.display = 'block';
        resultsSection.classList.add('fadeInUp');
        
        // Smooth scroll to results
        resultsSection.scrollIntoView({ behavior: 'smooth' });

        // Show success alert
        this.showAlert('✅ Night shift premium calculated successfully!', 'success');
    }

    formatCurrency(amount) {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(amount);
    }

    showAlert(message, type) {
        // Remove existing alerts
        const existingAlert = document.querySelector('.alert-dismissible');
        if (existingAlert) {
            existingAlert.remove();
        }

        // Create new alert
        const alert = document.createElement('div');
        alert.className = `alert alert-${type} alert-dismissible fade show`;
        alert.setAttribute('role', 'alert');
        alert.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;

        // Insert alert at the top of the container
        const container = document.querySelector('.container');
        container.insertBefore(alert, container.firstChild);

        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            if (alert.parentNode) {
                alert.remove();
            }
        }, 5000);
    }
}

// Initialize calculator when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new NightShiftCalculator();
});

// Add some helpful utility functions
window.NightShiftUtils = {
    exportResults: function() {
        const results = {
            timestamp: new Date().toISOString(),
            monthlySalary: document.getElementById('monthlySalary').value,
            totalHours: document.getElementById('totalHours').value,
            nightHours: document.getElementById('nightHours').value,
            overtimeHours: document.getElementById('overtimeHours').value,
            monthlyPremium: document.getElementById('monthlyPremium').textContent,
            totalWithPremium: document.getElementById('totalWithPremium').textContent
        };

        const dataStr = JSON.stringify(results, null, 2);
        const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
        
        const exportFileDefaultName = 'night_shift_calculation.json';
        
        const linkElement = document.createElement('a');
        linkElement.setAttribute('href', dataUri);
        linkElement.setAttribute('download', exportFileDefaultName);
        linkElement.click();
    },

    shareResults: function() {
        if (navigator.share) {
            const premium = document.getElementById('monthlyPremium').textContent;
            navigator.share({
                title: 'Night Shift Pay Calculator Results',
                text: `My night shift premium: ${premium}`,
                url: window.location.href
            });
        } else {
            // Fallback to copying to clipboard
            const premium = document.getElementById('monthlyPremium').textContent;
            const total = document.getElementById('totalWithPremium').textContent;
            const text = `Night Shift Premium: ${premium}\nTotal with Premium: ${total}`;
            
            navigator.clipboard.writeText(text).then(() => {
                alert('Results copied to clipboard!');
            });
        }
    }
};
