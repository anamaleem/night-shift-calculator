# WordPress Integration Guide - Night Shift Pay Calculator

## Overview
This guide provides three methods to integrate the Night Shift Pay Calculator into your WordPress website.

## Method 1: Custom HTML Block (Recommended for Beginners)

### Step 1: Copy the HTML File
1. Use the file `night-shift-calculator-wordpress.html`
2. Open it in a text editor
3. Copy ALL the content (HTML, CSS, and JavaScript)

### Step 2: Add to WordPress
1. Login to your WordPress admin dashboard
2. Go to **Pages** → **Add New** (or edit existing page)
3. Add a **Custom HTML** block
4. Paste the complete code from the HTML file
5. Update/Publish the page

### Advantages
- ✅ No plugin installation required
- ✅ Works immediately
- ✅ Easy to customize
- ✅ No technical knowledge needed

### Disadvantages
- ❌ Code must be copied to each page where you want the calculator
- ❌ Updates require manual code replacement

---

## Method 2: WordPress Plugin (Recommended for Multiple Uses)

### Step 1: Create Plugin Files
1. Create a new folder: `night-shift-calculator`
2. Add these files to the folder:
   - `night-shift-calculator.php` (main plugin file)
   - `night-shift-calculator.css` (styles)
   - `night-shift-calculator.js` (JavaScript)

### Step 2: Plugin Installation
1. Zip the folder: `night-shift-calculator.zip`
2. Login to WordPress admin
3. Go to **Plugins** → **Add New** → **Upload Plugin**
4. Upload the ZIP file
5. Activate the plugin

### Step 3: Usage
Add this shortcode to any page or post:
```
[night_shift_calculator]
```

### Customization Options
```
[night_shift_calculator currency="EUR" currency_symbol="€" title="Custom Title"]
```

### Advantages
- ✅ Easy to use with shortcode
- ✅ Can be used on multiple pages
- ✅ Customizable through shortcode attributes
- ✅ Professional implementation

---

## Method 3: Theme Integration (Advanced)

### Step 1: Add to Theme Files
1. Access your theme's `functions.php` file
2. Add the calculator function
3. Create a dedicated page template

### Step 2: Implementation
Add this code to your theme's `functions.php`:

```php
function render_night_shift_calculator() {
    // Include the calculator HTML/CSS/JS
    include get_template_directory() . '/calculator/night-shift-calculator.php';
}

// Add shortcode support
add_shortcode('night_shift_calc', 'render_night_shift_calculator');
```

### Advantages
- ✅ Fully integrated with your theme
- ✅ Better performance
- ✅ More customization options

### Disadvantages
- ❌ Requires theme modification
- ❌ May be lost during theme updates
- ❌ Requires technical knowledge

---

## Features Included

### Calculator Features
- **Monthly Salary Input** - Base salary calculation
- **Total Monthly Hours** - Standard work hours
- **Night Shift Hours** - Hours worked during night period
- **Overtime Hours** - Optional overtime calculation
- **20% Premium** - Standard night shift premium
- **Reduced Hours** - 52.5 minutes = 1 hour calculation
- **Real-time Validation** - Input error checking
- **Professional Results** - Detailed breakdown display

### Design Features
- **Responsive Design** - Works on mobile and desktop
- **Professional Styling** - Clean, modern interface
- **Print Functionality** - Print results for records
- **WordPress Compatible** - Integrates seamlessly
- **Accessibility** - Screen reader friendly
- **Fast Loading** - Optimized performance

---

## Customization Options

### Currency Settings
Change the currency symbol and formatting:
```javascript
// In the JavaScript section, modify:
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'EUR', // Change to your currency
        minimumFractionDigits: 2
    }).format(amount);
}
```

### Color Scheme
Modify the CSS variables:
```css
:root {
    --primary-color: #667eea;
    --secondary-color: #764ba2;
    --success-color: #4caf50;
    --warning-color: #ff9800;
}
```

### Labor Law Compliance
Update the premium rates for your region:
```javascript
// Modify these constants:
const NIGHT_PREMIUM_RATE = 0.20; // 20% (change as needed)
const OVERTIME_RATE = 0.50; // 50% (change as needed)
const HOUR_REDUCTION = 0.875; // 52.5 minutes = 1 hour
```

---

## SEO Optimization

### Meta Tags
Add these to your page/post:
```html
<meta name="description" content="Free night shift pay calculator with 20% premium calculation">
<meta name="keywords" content="night shift, pay calculator, overtime, premium, salary">
```

### Schema Markup
Add structured data for better search results:
```json
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "Night Shift Pay Calculator",
  "description": "Calculate night shift premium with 20% additional compensation",
  "category": "Finance"
}
```

---

## Support and Updates

### Getting Help
- Check the WordPress community forums
- Review the plugin documentation
- Test on a staging site first

### Updates
- Keep the calculator updated with current labor laws
- Test after WordPress updates
- Monitor for any compatibility issues

### Performance Tips
- Use caching plugins
- Optimize images
- Minimize HTTP requests
- Use CDN for better loading speeds

---

## Legal Considerations

### Important Notes
- Always include disclaimers about calculation accuracy
- Advise users to consult professionals for official calculations
- Keep updated with local labor laws
- Consider data privacy regulations

### Disclaimer Template
```
"This calculation is an estimate based on standard labor practices. 
Consult with a professional for specific cases or local regulations. 
Results may vary based on your employment contract and local laws."
```

---

## Conclusion

The Night Shift Pay Calculator is ready for WordPress integration using any of these three methods. Choose the method that best fits your technical comfort level and usage requirements.

For most users, **Method 1 (Custom HTML Block)** is the quickest and easiest solution. For websites that need the calculator on multiple pages, **Method 2 (WordPress Plugin)** provides the best user experience.